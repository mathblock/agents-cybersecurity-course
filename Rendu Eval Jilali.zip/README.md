# Livrables — Évaluation IA, agents et cybersécurité

Dossier de rendu complet pour l'étude de cas **AegisBot / Northwind Health Cloud**.

---

## Structure des livrables

| Fichier | Contenu |
|---|---|
| `01-modele-de-menace.md` | Actifs à protéger, sources non fiables, menaces par surface, impacts et contrôles prioritaires |
| `02-architecture-securisee.md` | Architecture logique sécurisée, séparation modèle / systèmes critiques, composants et gouvernance |
| `03-matrice-permissions.md` | Table complète des actions autorisées, conditionnelles, soumises à validation humaine ou interdites |
| `04-skill-kubernetes-incident-triage.md` | Conception d'une skill cyber sécurisée : structure, SKILL.md, script de collecte, template de rapport |
| `05-evaluation-monitoring.md` | Tests avant production, tests réguliers, logs, indicateurs, détection d'abus et critères de mise en production |

---

## Logique d'ensemble

Les cinq documents forment un ensemble cohérent et progressif :

1. Le **modèle de menace** identifie ce qui doit être protégé et contre quoi.
2. L'**architecture sécurisée** définit comment organiser les composants pour réduire la surface d'attaque.
3. La **matrice de permissions** traduit cette architecture en règles opérationnelles concrètes.
4. La **skill Kubernetes** illustre comment appliquer ces règles dans un cas d'usage réel.
5. Le **plan d'évaluation** fournit les outils pour vérifier que les contrôles fonctionnent et perdurent.

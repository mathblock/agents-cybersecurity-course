# 1. Modèle de menace — AegisBot

---

## 1.1 Actifs à protéger

Les actifs suivants sont classés par sensibilité croissante. Leur protection conditionne directement la sécurité de l'ensemble du système.

| Actif | Sensibilité | Risque principal |
|---|---|---|
| Données de santé hébergées | Très élevée | Fuite, non-conformité, atteinte patient/client |
| Données clients | Très élevée | Fuite contractuelle ou réglementaire |
| Logs Kubernetes et applicatifs | Élevée | Secrets, tokens, IP internes, chemins, erreurs sensibles |
| Tickets d'incident | Élevée | Informations d'attaque, noms d'actifs, données personnelles |
| Documents internes et runbooks | Élevée | Architecture, procédures, contournements possibles |
| Règles SIEM / Sigma | Élevée | Désactivation de détection ou bruit opérationnel |
| Rapports d'incident | Élevée | Fuite d'informations sensibles et réputationnelles |
| Secrets techniques | Critique | Compromission directe d'environnements |
| Configurations Kubernetes | Critique | Modification ou destruction de ressources |
| Identité technique d'AegisBot | Critique | Abus des permissions de l'agent |
| Prompts, skills, tools, serveurs MCP | Critique | Altération du comportement agentique |
| Logs d'audit de l'agent | Critique | Perte de traçabilité, dissimulation d'abus |

---

## 1.2 Sources de données et niveaux de confiance

**Règle fondamentale :** une source documentaire est une **donnée**, jamais une instruction. Seuls le prompt système validé, la politique de sécurité et l'orchestrateur de contrôle peuvent définir le comportement autorisé d'AegisBot.

| Source | Niveau de confiance | Justification |
|---|---|---|
| Prompt utilisateur | Faible à moyen | Peut contenir des demandes ambiguës ou malveillantes |
| Tickets d'incident | Faible | Peuvent contenir des instructions cachées ou des commentaires hostiles |
| Messages Slack SOC | Faible à moyen | Bruit, opinions, données sensibles, injections indirectes |
| Logs applicatifs / Kubernetes | Moyen | Faits utiles mais peuvent contenir des secrets ou des chaînes contrôlées par un attaquant |
| Documentation importée automatiquement | Faible à moyen | Provenance et fraîcheur variables |
| Historique d'incidents | Moyen | Utile mais contexte potentiellement dépassé |
| Runbooks internes validés | Moyen à élevé | Utiles mais peuvent être obsolètes ou empoisonnés |
| Règles Sigma existantes | Moyen à élevé | Contrôles pertinents mais non forcément adaptés au cas courant |
| Serveurs MCP / connecteurs | Variable | Dépend de l'approbation, de la version, des scopes et de l'audit |
| Skills | Variable | Doivent être auditées comme du logiciel exécutable |

---

## 1.3 Menaces sur les prompts

| Menace | Exemple concret | Impact | Contrôles associés |
|---|---|---|---|
| Injection directe | L'utilisateur demande d'ignorer les règles | Fuite ou action interdite | Hiérarchie d'instructions, policy engine, refus explicite |
| Injection indirecte | Un ticket contient `ignore les alertes` | Mauvaise analyse SOC | Classification des sources, isolation données / instructions |
| Injection multimodale | Texte caché dans une image ou un PDF | Contournement des règles | OCR contrôlé, étiquetage source, sandbox de parsing |
| Jailbreak métier | Reformulation d'une action interdite | Exécution non autorisée | Validation d'intention, allowlist d'actions |
| Persistance en mémoire | Instruction malveillante mémorisée entre sessions | Compromission durable | Mémoire limitée, expiration, revue périodique, purge |

---

## 1.4 Menaces sur le RAG et la base documentaire

| Menace | Description | Impact | Contrôles associés |
|---|---|---|---|
| RAG poisoning | Document interne empoisonné injecté dans l'index | Procédure dangereuse suivie par l'agent | Validation documentaire, signatures, scoring de confiance |
| Surpartage documentaire | Documents trop sensibles indexés sans filtrage | Fuite dans les réponses | DLP, filtrage par identité, minimisation |
| Documents obsolètes | Runbooks dépassés sans date de validation | Mauvaise recommandation opérationnelle | Versioning, date de validation, propriétaire désigné |
| Sources contradictoires | Deux procédures incompatibles dans l'index | Décision non fiable | Signalement de conflit, humain dans la boucle |
| Confusion donnée / instruction | Un runbook formule un ordre au modèle | Bypass du prompt système | Wrapper RAG : contenu explicitement marqué non normatif |

---

## 1.5 Menaces sur les tools, skills et serveurs MCP

| Surface | Menace | Impact | Contrôles associés |
|---|---|---|---|
| Tool terminal | Commande destructive exécutée automatiquement | Indisponibilité en production | Sandbox, allowlist read-only, approbation humaine |
| Tool Jira | Fermeture ou modification abusive d'un ticket | Perte de suivi d'incident | Scopes séparés créer / modifier / fermer, approbation |
| Tool Slack | Fuite vers l'extérieur ou canal interne trop large | Non-conformité réglementaire | DLP, canaux autorisés, validation avant envoi |
| Tool SIEM | Désactivation d'une règle d'alerte | Perte de détection | Interdiction automatique ou validation forte |
| API Kubernetes | Modification d'une ressource de production | Impact production direct | Identité read-only, séparation prod / sandbox |
| Skill | Script malveillant embarqué | Exfiltration ou action cachée | Revue de code, signature, registre approuvé |
| Serveur MCP | Tool poisoning ou shadow server | Backdoor ou scope creep | Registry, allowlist, attestation, audit logs |
| Arguments de tool | Injection de commande via paramètre | Exécution arbitraire | Schémas stricts, validation, échappement, refus shell libre |

---

## 1.6 Menaces sur les logs et rapports générés

Les sorties produites par AegisBot peuvent elles-mêmes constituer un vecteur de risque :

- Inclusion de secrets non masqués dans un rapport ou un log.
- Hallucination d'une preuve inexistante présentée comme certaine.
- Rapport trop affirmatif, sans citation de sources vérifiables.
- Omission d'une instruction malveillante pourtant détectée.
- Falsification ou suppression de logs d'audit.
- Envoi automatique à une audience trop large sans validation préalable.

**Contrôles applicables :** logs immuables, masquage systématique des secrets, séparation explicite faits / hypothèses / recommandations, citations obligatoires, validation humaine avant toute diffusion externe ou sensible.

---

## 1.7 Impacts potentiels

En cas d'exploitation réussie d'une menace, les impacts possibles incluent :

- Fuite de données de santé, de données clients ou de secrets techniques.
- Exécution de commandes destructives en production.
- Désactivation ou affaiblissement de la détection SIEM.
- Mauvaise qualification d'un incident réel.
- Création, fermeture ou modification abusive de tickets.
- Propagation de procédures empoisonnées dans les runbooks.
- Perte d'auditabilité en cas d'incident causé par l'agent.

---

## 1.8 Contrôles prioritaires

Les contrôles suivants sont ordonnés par importance et doivent tous être en place avant toute mise en production.

1. **Identité dédiée AegisBot** avec droits minimaux (principe du moindre privilège).
2. **Policy layer obligatoire** avant tout appel de tool.
3. **Tool gateway** avec allowlist, schémas d'arguments stricts et journalisation complète.
4. **Sandbox isolée** pour les diagnostics, sans accès aux secrets ni écriture en production.
5. **RAG gouverné** : provenance, version, score de confiance, validation documentaire.
6. **Human approval** pour toute action critique ou diffusion sensible.
7. **DLP et masquage de secrets** sur les entrées et les sorties.
8. **Registry approuvé** de tools, skills et serveurs MCP.
9. **Logs immuables** et corrélables avec chaque session agentique.
10. **Red teaming régulier** des prompts, du RAG, des tools, des skills et des connecteurs.

# 2. Architecture sécurisée d'AegisBot

---

## 2.1 Principe général

AegisBot ne doit jamais appeler directement les systèmes critiques. Le modèle propose, l'orchestrateur décide, la policy autorise ou refuse, la tool gateway exécute uniquement les actions permises, et l'humain valide les actions sensibles.

Ce principe se traduit par la chaîne de traitement suivante :

```
Utilisateur SOC
    │
    ▼
Interface AegisBot
    │
    ▼
Orchestrateur agentique
    │
    ├──▶ Policy layer / Risk engine
    │         - Classification de l'action
    │         - Contrôle identité et scopes
    │         - Règles d'approbation humaine
    │         - DLP sur entrées et sorties
    │
    ├──▶ RAG sécurisé
    │         - Documents signés et versionnés
    │         - Score de confiance par source
    │         - Séparation données / instructions
    │
    └──▶ Tool gateway
              │
              ├──▶ SIEM read-only
              ├──▶ Logs Kubernetes filtrés read-only
              ├──▶ Jira (création limitée)
              ├──▶ Slack (brouillon / envoi contrôlé)
              ├──▶ Sandbox diagnostic read-only
              └──▶ Registry MCP approuvé
```

---

## 2.2 Séparation modèle / systèmes critiques

La séparation stricte entre le LLM et les systèmes critiques est non négociable :

- Le LLM ne reçoit aucun secret brut.
- Le LLM ne détient aucun token de production.
- Les tools sont appelés via une gateway, jamais directement depuis le modèle.
- Les commandes sont représentées par des intentions structurées, pas par un shell libre.
- Les actions critiques sont bloquées ou mises en attente de validation humaine.

---

## 2.3 Composants attendus

| Composant | Rôle de sécurité |
|---|---|
| Interface utilisateur | Authentification, contexte utilisateur, avertissements affichés |
| Orchestrateur | Contrôle du cycle agentique, séparation faits / hypothèses / actions |
| Policy layer | Décision autoriser / refuser / demander une validation |
| Tool gateway | Point unique d'exécution contrôlée |
| Sandbox | Diagnostics isolés, sans privilèges de production |
| RAG sécurisé | Documents gouvernés avec provenance, version et score de confiance |
| IAM | Identité agent dédiée, RBAC minimal |
| Secret manager | Secrets hors prompt ; injection minimale côté tool si nécessaire |
| Human approval | Frein d'urgence et décision métier |
| Audit logs | Traçabilité complète et immuable |
| Monitoring | Détection d'abus, dérive de comportement, erreurs |
| Skill registry | Validation, versionnement et signature des skills |
| MCP registry | Connecteurs approuvés avec scopes et versionnement |

---

## 2.4 Gestion des permissions

Les scopes sont strictement séparés selon quatre niveaux :

- **Lecture** : fortement filtrée en production.
- **Écriture** : interdite par défaut en production.
- **Exécution** : read-only limitée possible en sandbox uniquement.
- **Secrets** : accès interdit au LLM ; seuls certains tools backend peuvent y accéder, avec masquage systématique en sortie.

---

## 2.5 Validation et déclaration des tools

Chaque tool doit obligatoirement déclarer les attributs suivants avant toute activation :

| Attribut | Description |
|---|---|
| Nom stable | Identifiant unique et immuable |
| Finalité métier | Objectif fonctionnel clairement exprimé |
| Schéma des arguments | Schéma strict, sans champ libre |
| Scopes nécessaires | Droits minimaux requis |
| Environnements autorisés | Prod, sandbox, staging, etc. |
| Niveau de criticité | Classification de l'impact potentiel |
| Politique de logs | Ce qui est enregistré et comment |
| Exemples autorisés et interdits | Cas d'usage valides et invalides |
| Propriétaire technique | Responsable identifié |
| Version | Numéro de version et date |

Tout tool inconnu ou modifié sans validation préalable est automatiquement refusé.

---

## 2.6 Exécution de commandes

AegisBot peut proposer des commandes mais ne peut exécuter automatiquement que des diagnostics read-only dans une sandbox approuvée.

**Autorisés en sandbox :**

```bash
kubectl get pods --all-namespaces
kubectl describe pod <pod> -n <namespace>
kubectl logs <pod> -n <namespace> --tail=200
kubectl get events -n <namespace>
```

**Interdits automatiquement (aucune exception côté agent) :**

```bash
kubectl delete
kubectl apply
kubectl patch
kubectl edit
kubectl exec
helm upgrade
systemctl restart
rm -rf
curl | sh
```

---

## 2.7 RAG sécurisé

La base documentaire doit respecter les exigences suivantes :

- Index séparés par niveau de sensibilité.
- Chaque document porte : propriétaire, date de validation, version et statut.
- Score de confiance affiché dans chaque réponse s'appuyant sur le RAG.
- Citations obligatoires pour toute recommandation.
- Conflits documentaires remontés explicitement, sans conclusion forcée.
- Les instructions trouvées dans les documents sont traitées comme du contenu non fiable.

---

## 2.8 Logs d'audit

Les logs doivent être immuables et contenir au minimum :

- Identité utilisateur et identifiant agent.
- Version du modèle et du prompt système.
- Objectif demandé et prompt utilisateur.
- Sources consultées et scores de confiance associés.
- Tools appelés, arguments fournis et résultats filtrés.
- Décision de la policy (autorisation, refus, demande de validation).
- Action proposée, action exécutée et validation humaine éventuelle.
- Erreurs et refus, journalisés comme événements de sécurité.

---

## 2.9 Actions nécessitant une validation humaine obligatoire

Les actions suivantes ne peuvent jamais être exécutées automatiquement par AegisBot :

- Toute modification en production.
- Toute exécution de commande en production.
- Accès ou manipulation de secrets.
- Envoi Slack contenant des données sensibles.
- Fermeture d'un incident.
- Désactivation ou modification d'une règle SIEM.
- Appel réseau externe non approuvé.
- Activation d'une skill ou d'un serveur MCP non encore validé.

---

## 2.10 Gouvernance des tools et connecteurs MCP

Pour prévenir l'apparition de shadow tools ou shadow MCP :

- Un **registry central** est obligatoire et fait référence.
- Une **allowlist par environnement** est maintenue et auditée.
- Chaque connecteur est **signé et hashé** ; tout changement déclenche une alerte.
- Un **inventaire continu** des serveurs MCP actifs est réalisé et comparé au registry.
- Les serveurs locaux ou externes non déclarés sont **bloqués automatiquement**.
- Tout nouveau tool ou changement de scope déclenche une **alerte de sécurité**.

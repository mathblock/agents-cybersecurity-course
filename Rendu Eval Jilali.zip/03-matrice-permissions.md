# 3. Matrice de permissions — AegisBot

---

## 3.1 Tableau des permissions

Le tableau ci-dessous recense l'ensemble des actions qu'AegisBot peut rencontrer, avec leur décision associée, les conditions requises et la justification de sécurité.

| Action | Décision | Conditions | Justification |
|---|---|---|---|
| Lire une alerte SIEM | ✅ Autorisé | Read-only, utilisateur SOC authentifié | Nécessaire au triage |
| Lire logs Kubernetes filtrés | ⚠️ Conditionnel | Namespace autorisé, masquage secrets, limite volume | Utile mais sensible |
| Lire logs bruts non filtrés | ❌ Interdit par défaut | Exception humaine documentée requise | Risque d'exposition de secrets |
| Lire secrets Kubernetes | ❌ Interdit | Aucune exception côté LLM | Secrets hors du contexte modèle |
| Consulter un runbook validé | ✅ Autorisé | Afficher version, propriétaire et score de confiance | Support décisionnel |
| Consulter un document non validé | ⚠️ Conditionnel | Marqué non fiable, non traité comme instruction | Prévention d'injection indirecte |
| Créer un ticket Jira | ⚠️ Conditionnel | Brouillon ou création avec template validé | Action réversible mais traçable |
| Modifier un ticket Jira | 🔒 Validation humaine | Préciser le champ modifié et la raison | Risque de désorganisation |
| Fermer un ticket | 🔒 Validation humaine obligatoire | Preuve et approbateur identifié requis | Action critique et irréversible |
| Générer une commande Linux | ✅ Autorisé | Sortie en proposition, non exécutée | Aide à l'opérateur |
| Exécuter commande diagnostic read-only en sandbox | ⚠️ Conditionnel | Allowlist stricte, logs, pas de secrets | Utile et borné |
| Exécuter commande en production | 🔒 Validation humaine obligatoire | Break-glass, journalisation renforcée | Impact production possible |
| `kubectl get / describe / logs` en sandbox | ⚠️ Conditionnel | Namespace autorisé, limite de sortie | Diagnostic limité |
| `kubectl delete / patch / apply / edit` | ❌ Interdit automatique | Action réservée à un humain hors agent | Destructif ou modifiant |
| `kubectl exec` | ❌ Interdit automatique | Exception manuelle hors agent uniquement | Accès interactif risqué |
| Désactiver une règle SIEM | ❌ Interdit automatique | CAB ou validation sécurité hors agent | Perte de capacité de détection |
| Proposer une règle Sigma | ✅ Autorisé | Marquée brouillon, revue humaine requise | Production de contenu non destructif |
| Déployer une règle Sigma | 🔒 Validation humaine obligatoire | Test + approbation formelle | Risque de faux positifs / négatifs |
| Envoyer un résumé sur le canal Slack SOC interne | ⚠️ Conditionnel | DLP, canal allowlist, aucun secret | Communication contrôlée |
| Envoyer un résumé vers l'extérieur | 🔒 Validation humaine obligatoire | Revue du contenu et du destinataire | Risque de fuite |
| Installer une dépendance | ❌ Interdit automatique | Pipeline approuvé uniquement | Risque supply chain |
| Utiliser une skill validée | ⚠️ Conditionnel | Version signée, scopes compatibles | Module audité |
| Utiliser une skill non validée | ❌ Interdit | Revue préalable obligatoire | Une skill est du logiciel exécutable |
| Appeler un serveur MCP approuvé | ⚠️ Conditionnel | Scopes minimaux, logs activés | Connecteur gouverné |
| Appeler un serveur MCP non approuvé | ❌ Interdit | Ajout au registry requis au préalable | Risque shadow MCP |
| Accéder à Internet | ❌ Interdit par défaut | Allowlist + validation explicite | Risque d'exfiltration |
| Révéler des données de santé ou clients | ❌ Interdit | Masquage et synthèse minimale uniquement | Conformité réglementaire |
| Répondre sans preuve ni source | ❌ Interdit fonctionnel | Demander la source ou signaler l'incertitude | Prévention de l'overreliance |

---

## 3.2 Règles transverses

Les règles suivantes s'appliquent à toutes les actions sans exception.

1. **Lecture ≠ écriture ≠ exécution** : chaque niveau dispose d'un scope séparé et indépendant.
2. **Toute action modifiant la production** nécessite une validation humaine explicite.
3. **Les secrets ne doivent jamais être transmis au LLM**, quelle que soit la raison invoquée.
4. **Les documents non fiables ne peuvent pas modifier les règles de comportement de l'agent.**
5. **Toute action doit produire une trace d'audit** complète et immuable.
6. **Les refus sont journalisés** comme des événements de sécurité à part entière.

---

## 3.3 Lecture du tableau

| Icône | Signification |
|---|---|
| ✅ Autorisé | L'action est permise sous les conditions indiquées |
| ⚠️ Conditionnel | L'action est permise uniquement si toutes les conditions sont réunies |
| 🔒 Validation humaine | L'action est bloquée jusqu'à approbation explicite d'un opérateur |
| ❌ Interdit | L'action est bloquée automatiquement, sans exception possible côté agent |
